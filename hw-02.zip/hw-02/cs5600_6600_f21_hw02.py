#!/usr/bin/python

#########################################
# module: cs5600_6600_f21_hw02.py
# YOUR NAME: Maxwell Thomas
# YOUR A# A02215231
#########################################

import numpy as np
import pickle
from cs5600_6600_f21_hw02_data import *

# sigmoid function and its derivative.
# you'll use them in the training and fitting
# functions below.


def sigmoidf(x):
    return 1 / (1 + (np.exp(-x)))


def sigmoidf_prime(x):
    return x * (1-x)

# persists object obj to a file with pickle.dump()
def save(obj, file_name):
    with open(file_name, 'wb') as fp:
        pickle.dump(obj, fp)

# restores the object from a file with pickle.load()
def load(file_name):
    with open(file_name, 'rb') as fp:
        obj = pickle.load(fp)
    return obj

def build_nn_wmats(mat_dims):
    layer = []
    for i in range(len(mat_dims) - 1):
        n1 = np.random.uniform(0, 1, [mat_dims[i], mat_dims[i + 1]])
        layer.append(n1)
    return tuple(layer)


def build_231_nn():
    return build_nn_wmats((2, 3, 1))


def build_2331_nn():
    return build_nn_wmats((2, 3, 3, 1))


def build_221_nn():
    return build_nn_wmats((2, 2, 1))


def build_838_nn():
    return build_nn_wmats((8, 3, 8))


def build_949_nn():
    return build_nn_wmats((9, 4, 9))


def build_4221_nn():
    return build_nn_wmats((4, 2, 2, 1))


def build_421_nn():
    return build_nn_wmats((4, 2, 1))


def build_121_nn():
    return build_nn_wmats((1, 2, 1))


def build_1221_nn():
    return build_nn_wmats((1, 2, 2, 1))


## Training 3-layer neural net.
## X is the matrix of inputs
## y is the matrix of ground truths.
## build is a nn builder function.
def train_3_layer_nn(numIters, X, y, build):
    w1, w2 = build()
    for i in range(numIters):
        # Feedforward
        Z2 = np.dot(X, w1)
        a2 = sigmoidf(Z2)
        Z3 = np.dot(a2, w2)
        a3 = sigmoidf(Z3)

        # Backprop
        a3_error = y - a3
        a3_delta = a3_error * sigmoidf_prime(a3)
        w2 += a2.T.dot(a3_delta)

        a2_error = a3_delta.dot(w2.T)
        a2_delta = a2_error * sigmoidf_prime(a2)
        w1 += X.T.dot(a2_delta)
    return w1, w2


def train_4_layer_nn(numIters, X, y, build):
    w1, w2, w3 = build()
    for j in range(numIters):
        # Feedforward
        Z2 = np.dot(X, w1)
        a2 = sigmoidf(Z2)
        Z3 = np.dot(a2, w2)
        a3 = sigmoidf(Z3)
        Z4 = np.dot(a3, w3)
        a4 = sigmoidf(Z4)

        # Backprop
        a4_error = y - a4
        a4_delta = a4_error * sigmoidf_prime(a4)
        w3 += a3.T.dot(a4_delta)

        a3_error = a4_delta.dot(w3.T)
        a3_delta = a3_error * sigmoidf_prime(a3)
        w2 += a2.T.dot(a3_delta)

        a2_error = a3_delta.dot(w2.T)
        a2_delta = a2_error * sigmoidf_prime(a2)
        w1 += X.T.dot(a2_delta)
    return w1, w2, w3


def fit_3_layer_nn(x, wmats, thresh=0.4, thresh_flag=False):
    # feed forward
    a = [x]
    for w in wmats:
        a.append(sigmoidf(np.dot(a[-1], w)))

    if thresh_flag:
        return sum(a[-1]) / len(a[-1]) > thresh

    return sum(a[-1]) / len(a[-1])


def fit_4_layer_nn(x, wmats, thresh=0.4, thresh_flag=False):
    a = [x]
    for w in wmats:
        a.append(sigmoidf(np.dot(a[-1], w)))

    if thresh_flag:
        return sum(a[-1]) / len(a[-1]) > thresh

    return sum(a[-1]) / len(a[-1])

#and_3_layer_ann.pck took 300 iterations and was 2x3x1
#or_3_layer_ann.pck took 300 iterations and was 2x3x1
#not_3_layer_ann.pck took 300 iterations and was 1x2x1
#xor_3_layer_ann.pck took 300 iterations and was 2x3x1
#bool_3_layer_ann.pck took 300 iterations and was 4x2x1

#and_4_layer_ann.pck took 500 iterations and was 2x3x3x1
#or_4_layer_ann.pck took 500 iterations and was 2x3x3x1
#not_4_layer_ann.pck took 500 iterations and was 1x2x2x1
#xor_4_layer_ann.pck took 500 iterations and was 2x3x3x1
#bool_4_layer_ann.pck took 500 iterations and was 4x2x2x1