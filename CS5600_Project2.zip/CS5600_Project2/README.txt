The first step in running this project is to install cmake otherwise OpenAI Gym might not work.

In order for this project to run correctly, specific versions of python and some packages must be used:
- Python version 3.7 (3.6 should work too, but I used 3.7)
- gym version 0.19.0 (Won't work with most recent version 0.21.0)
- atari-py version 0.2.6 (Won't work with most recent version 0.3.0)
- numpy I used version 1.19.5 (I'm not sure if version 1.21.4 will work)

I tried using pip to install these versions but something was broken so I had to use the python packages tab.

After installing these programs, run the main function in main.py to run the project.

Once the program is running, a window will be opened with a game of Pong running.
If the window does not open but you can see episode rewards and means being printed uncomment env.render().
This should now display the game of Pong.
The red AI is from OpenAI Gym and the green AI is the one the program is training.
Overtime the green AI should be able to beat the red AI, but this might take a couple of days.
I trained the AI on my computer for two days and it got to the point it where it was winning around 10 rounds but my
computer crashed before the AI could win consistently.

The parameters can be found in the beginning of the main function and can be changed to try an increase training speed.
Search parameters in finder if you do not see them

Thanks for the suggestion to start with a simple NN because I was not able to get a convolutional NN to work in time.
This limits how quickly the AI can learn, but it still works after a long training period.
I was also trying to implement the ability to save the model using pickle, but I didn't have the time to finish.
I was able however to get backpropagation to work with the gradients so overtime the AI has a better idea of which
action would be the best one.

