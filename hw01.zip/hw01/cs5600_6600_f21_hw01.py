
####################################################
# CS 5600/6600: F20: Assignment 1
# YOUR NAME: Maxwell Thomas
# YOUR A#02215231
#####################################################

import numpy as np

class and_percep:

    def __init__(self):
        self.bias = np.array([0])
        self.weights = np.array([0.26, 0.26])
        pass
        
    def output(self, x):
        return np.round(np.dot(x, self.weights) + self.bias)
        pass

class or_percep:
    
    def __init__(self):
        self.bias = np.array([0.0])
        self.weights = np.array([0.51, 0.51])
        pass

    def output(self, x):
        return np.round(np.dot(x, self.weights) + self.bias)
        pass

class not_percep:
    
    def __init__(self):
        self.bias = np.array([1.0])
        self.weights = np.array([-1.0])
        pass

    def output(self, x):
        return np.round(np.dot(x, self.weights) + self.bias)
        pass

class xor_percep:
    
    def __init__(self):
        self.and_ = and_percep()
        self.or_ = or_percep()
        self.not_ = not_percep()
        pass

    def output(self, x):
        left = self.not_.output(self.and_.output(x))
        right = self.or_.output(x)
        return self.and_.output([left[0], right[0]])

class xor_percep2:
    def __init__(self):
        self.b1 = np.array([-1.0])
        self.b2 = np.array([-1.0])
        self.b3 = np.array([0])
        self.w1 = np.array([0.6, 0.51])
        self.w2 = np.array([1.1, 1.1])
        self.w3 = np.array([-1.5, 1.01])
        pass

    def threshold(self, x):

        pass
    
    def output(self, x):
        n1 = np.dot(x, self.w1) + self.b1
        n2 = np.dot(x, self.w2) + self.b2
        n3 = np.dot([n1[0], n2[0]], self.w3) + self.b3
        return np.round(n3) if n3[0] < 1 else np.array([0])

class percep_net:
    
    def __init__(self):
        self.and_ = and_percep()
        self.or_ = or_percep()
        self.not_ = not_percep()
        pass

    def output(self, x):
        # n1 = self.and_.output(x)
        # n2 = self.not_.output(n1)
        # n3 = self.or_.output(x)
        # new_x = np.array([n2, n3])
        # n1(new_x)
        return

    
        





